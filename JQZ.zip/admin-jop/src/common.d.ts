declare module 'wangeditor';

declare module 'fabric';

declare module 'vuedraggable';

declare module 'sortablejs';

declare module 'v-charts/lib/line.common';

declare module 'v-charts/lib/histogram.common';

declare module 'qrious';

declare module 'clipboard';

declare const VUE_APP_BASE_API: string;