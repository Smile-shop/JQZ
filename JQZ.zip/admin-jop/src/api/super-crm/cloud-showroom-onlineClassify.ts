import request from '@/utils/request'

export function getOnlineClassify(data: any) {
  return request({
    url: '',
    method: 'POST',
    data
  })
}