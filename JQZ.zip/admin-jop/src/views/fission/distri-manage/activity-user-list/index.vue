<template>
  <div class="activity-user-list">
    2222
  </div>
</template>

<script lang="ts">
import {Vue, Component} from 'vue-property-decorator';

@Component({
})
export default class ActivityUserList extends Vue {
}
</script>

<style lang="scss" scoped>
</style>
