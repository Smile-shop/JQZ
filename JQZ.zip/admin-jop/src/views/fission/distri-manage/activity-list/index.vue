<template>
  <div class="activity-list">
    111
  </div>
</template>

<script lang="ts">
import {Vue, Component} from 'vue-property-decorator';

@Component({
})
export default class ActivityList extends Vue {
}
</script>

<style lang="scss" scoped>
</style>
