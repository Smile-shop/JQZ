<template>
  <div class="distri-manage">
    <router-view/>
  </div>
</template>

<script lang="ts">
import {Vue, Component, Prop} from 'vue-property-decorator';

@Component({
})
export default class DistriManage extends Vue {
}
</script>
