<template>
  <div class="nine">
      <router-view/> 
  </div>
</template>

<script lang="ts">
import {Vue, Component, Prop} from 'vue-property-decorator';

@Component({
})
export default class PrizeSetNine extends Vue {

}
</script>

<style lang="scss" scoped>
</style>


