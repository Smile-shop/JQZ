<template>
  <div class="system-setting">
    <router-view/>
  </div>
</template>

<script lang="ts">
import {Vue, Component, Prop} from 'vue-property-decorator';

@Component({
})
export default class SystemSetting extends Vue {
}
</script>


