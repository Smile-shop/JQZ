<template>
  <div>
    <router-view/>
  </div>
</template>

<script lang="ts">
import {Vue, Component} from 'vue-property-decorator';

@Component({
})
export default class FunctionFocus extends Vue {
}
</script>
