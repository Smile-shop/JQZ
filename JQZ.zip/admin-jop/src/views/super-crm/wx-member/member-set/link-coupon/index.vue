<template>
  <router-view></router-view>
</template> 

<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator';

@Component({
  components: {},
})
export default class PositionManage extends Vue {}
</script>
