<template>
  <div class="wx-member">
    <router-view/>
  </div>
</template>

<script lang="ts">
import {Vue, Component, Prop} from 'vue-property-decorator';

@Component({
})
export default class WxMember extends Vue {
}
</script>


