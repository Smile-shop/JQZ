<template>
  <div class="member-function">
    <router-view/>
  </div>
</template>

<script lang="ts">
import {Vue, Component, Prop} from 'vue-property-decorator';

@Component({
})
export default class MemberFunction extends Vue {
}
</script>
