<template>
  <div class="quality-policy-set">
    <router-view/>
  </div>
</template>

<script lang="ts">
import {Vue, Component, Prop} from 'vue-property-decorator';

@Component({
})
export default class QualityPolicySet extends Vue {
}
</script>

<style lang="scss" scoped>
.quality-policy-set {
}
</style>


