<template>
  <div class="wx-quality-policy">
    <router-view/>
  </div>
</template>

<script lang="ts">
import {Vue, Component, Prop} from 'vue-property-decorator';

@Component({
})
export default class WxQualityPolicy extends Vue {
}
</script>

<style lang="scss" scoped>
.wx-quality-policy {
}
</style>


