<template>
  <router-view/>
</template>

<script lang="ts">
import {Vue, Component, Prop, Watch} from 'vue-property-decorator';
import {} from '@/api/super-crm/wx-mall';

@Component({
})
export default class SalesmanSalesData extends Vue {
}
</script>

<style lang="scss" scoped>
.salesman-sales-data {
}
</style>
