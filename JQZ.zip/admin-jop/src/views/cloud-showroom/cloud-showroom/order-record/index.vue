<template>
  <div>
    <router-view/>
  </div>
</template>

<script lang="ts">
import {Vue, Component} from 'vue-property-decorator';

@Component({
})
export default class MemberRegister extends Vue {
}
</script>