<template>
  <div class="cloud-showroom-home">
  </div>
</template>

<script lang="ts">
import {Vue, Component, Prop} from 'vue-property-decorator';

@Component({
  components: {
  }
})
export default class CloudShowroomHome extends Vue {
}
</script>

<style lang="scss" scoped>
.cloud-showroom-home {
}
</style>
