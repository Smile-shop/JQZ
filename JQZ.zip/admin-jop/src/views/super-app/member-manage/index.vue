<template>
  <div class="member-manage">
    <router-view/>
  </div>
</template>

<script lang="ts">
import {Vue, Component, Prop} from 'vue-property-decorator';

@Component({
})
export default class AppPhone extends Vue {
}
</script>

