<template>
  <div class="data-count">
    <router-view/>
  </div>
</template>

<script lang="ts">
import {Vue, Component, Prop} from 'vue-property-decorator';

@Component({
})
export default class DataCount extends Vue {
}
</script>


