<template>
  <div class="system-set">
    <router-view/>
  </div>
</template>

<script lang="ts">
import {Vue, Component, Prop} from 'vue-property-decorator';

@Component({
})
export default class SystemSet extends Vue {
}
</script>


