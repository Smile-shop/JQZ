<template>
  <div class="app-gutter">
  </div>
</template>

<script lang="ts">
import {Vue, Component} from 'vue-property-decorator';

@Component({
})
export default class AppGutter extends Vue {
}
</script>

<style lang="scss" scoped>
.app-gutter{
  height: 20px;;
}
</style>


