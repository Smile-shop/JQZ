const baseUrl = '/super-app/home'

const menu = {
  appName: '首页',
  appCode: '',
  canAccess: true,
  path: baseUrl,
  icon: '',
  hidden: true,
  children: [
  ]
}

export default menu;