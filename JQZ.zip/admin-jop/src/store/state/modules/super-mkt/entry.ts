const baseUrl = '/super-mkt/home'

const menu = {
    appName: '活动列表',
    appCode: 'activitySet',
    canAccess: false,
    path: baseUrl,
    icon: 'icon-shezhi1',
    children: [],
}

export default menu;
