window.VUE_APP_BASE_API = `${location.protocol}//www.jbfsoft.net`
// window.VUE_APP_BASE_API = `${location.protocol}//test2.jqzjop.com`

// window.VUE_APP_BASE_API = `${location.protocol}//www.jbfsoft.net`
